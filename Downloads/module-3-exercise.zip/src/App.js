import "./styles.css";
import FormSearch from "./pages/home/index.js";
import GifData from "./components/component/index";

export default function App() {
  return (
    <div className="App">
      <FormSearch
        judul="Exercise"
        GifSatuSrc="https://media.giphy.com/media/Vh8pbGX3SGRwFDh3V0/source.gif"
      />
      <GifData />
    </div>
  );
}