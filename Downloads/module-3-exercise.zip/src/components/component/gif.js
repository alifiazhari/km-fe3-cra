export default function Gif(props) {
  return (
    <div>
      <h3>{props.judul}</h3>
      <img src={props.GifSrcSatu} alt="gif" />
    </div>
  );
}