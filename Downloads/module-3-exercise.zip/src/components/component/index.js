import React, { Component } from "react";
import "./index.css";
import Gif from "./gif";
import data from "./data";

class GifData extends Component {
  render() {
    return (
      <div>
        <Gif judul={data.title} GifSrcSatu={data.url} />
      </div>
    );
  }
}
export default GifData;