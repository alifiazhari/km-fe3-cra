import "./index.css";
const FromSearch = (props) => (
  <form>
    <h1>{props.judul}</h1>
    <input
      type="text"
      className="search-input"
      placeholder="Search here"
    ></input>
    <input type="submit" className="search-button" value="Search"></input>
    <div>
      <img src={props.GifSatuSrc} alt="gif" />
    </div>
  </form>
);

export default FromSearch;